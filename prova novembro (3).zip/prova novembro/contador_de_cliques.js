function contadorDeCliques() {
  let contador = 0;
  contador++;
  return contador;
  document.getElementById("contador").innerHTML = contador;
}
