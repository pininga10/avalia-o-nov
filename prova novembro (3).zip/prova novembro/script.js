function media() {
  let nom = window.prompt("Qual é o nome do aluno?");
  let n1 = Number(window.prompt(`Digite sua primeira nota   ${nom}?`));
  let n2 = Number(
    window.prompt(`Além de ${n1}, qual foi sua outra nota, por favor,${nom}?`)
  );
  med = (n1 + n2) / 2;
  let res = document.getElementById("situacao");
  res.innerHTML = `<p>Calculando a média final de <mark>${nom}</mark>.</p>`;
  res.innerHTML += `<p>As notas obtidas foram <mark>${n1} e ${n2}</mark>.</p>`;
  res.innerHTML += `<p>Sua média final será <mark>${med}</mark>.</p>`;
}

function calcular() {
  let num = Number(window.prompt("Digite um número: "));

  let res = document.querySelector("section#result");
  res.innerHTML = `<p>O número a ser analisado aqui será o <strong>${num}</strong></p>`;
  res.innerHTML += `<p>O seu valor absoluto é ${Math.abs(num)}</p>`;
  res.innerHTML += `<p>A sua parte inteira é ${Math.trunc(num)}</p>`;
  res.innerHTML += `<p>O valor inteiro mais próximo é ${Math.round(num)}</p>`;
  res.innerHTML += `<p>A sua raiz quadrada é ${Math.sqrt(num)}</p>`;
  res.innerHTML += `<p>A sua raiz cúbica é ${Math.cbrt(num)}</p>`;
  res.innerHTML += `<p>O valor de ${num}<sup>2</sup> é ${Math.pow(num, 2)}</p>`;
  res.innerHTML += `<p>O valor de ${num}<sup>3</sup> é ${Math.pow(num, 3)}</p>`;
}
